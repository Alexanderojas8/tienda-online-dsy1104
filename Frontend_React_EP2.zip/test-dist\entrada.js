(() => {
  // src/utils/formatoPrecio.js
  function formatearPrecio(precio) {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      maximumFractionDigits: 0
    }).format(Number(precio));
  }

  // tests/formatoPrecio.spec.js
  describe("Formato de precios de la tienda", () => {
    it("debe mostrar un precio en pesos chilenos", () => {
      const resultado = formatearPrecio(2e4);
      expect(resultado).toContain("20.000");
    });
    it("debe formatear correctamente un precio de 39990", () => {
      const resultado = formatearPrecio(39990);
      expect(resultado).toContain("39.990");
    });
    it("debe aceptar precios recibidos como texto", () => {
      const resultado = formatearPrecio("15000");
      expect(resultado).toContain("15.000");
    });
    it("debe formatear correctamente el valor cero", () => {
      const resultado = formatearPrecio(0);
      expect(resultado).toContain("0");
    });
  });

  // src/utils/carritoUtils.js
  function agregarAlCarrito(carrito, producto) {
    const existente = carrito.find(
      (item) => item.id === producto.id
    );
    const cantidadActual = existente?.cantidad || 0;
    if (cantidadActual >= Number(producto.stock)) {
      return carrito;
    }
    if (existente) {
      return carrito.map(
        (item) => item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item
      );
    }
    return [...carrito, { ...producto, cantidad: 1 }];
  }
  function modificarCantidad(carrito, id, cambio) {
    return carrito.map((item) => {
      if (item.id !== id) {
        return item;
      }
      const nuevaCantidad = item.cantidad + cambio;
      if (nuevaCantidad > Number(item.stock)) {
        return item;
      }
      return {
        ...item,
        cantidad: nuevaCantidad
      };
    }).filter((item) => item.cantidad > 0);
  }
  function quitarProducto(carrito, id) {
    return carrito.filter((item) => item.id !== id);
  }
  function calcularCantidadTotal(carrito) {
    return carrito.reduce(
      (total, item) => total + item.cantidad,
      0
    );
  }
  function calcularPrecioTotal(carrito) {
    return carrito.reduce(
      (total, item) => total + Number(item.precio) * item.cantidad,
      0
    );
  }

  // tests/carrito.spec.js
  describe("Pruebas unitarias del carrito", () => {
    const mouse = {
      id: 1,
      nombre: "Mouse Gamer",
      precio: 2e4,
      stock: 5
    };
    const teclado = {
      id: 2,
      nombre: "Teclado Mec\xE1nico",
      precio: 39990,
      stock: 3
    };
    it("debe agregar un producto al carrito", () => {
      const resultado = agregarAlCarrito([], mouse);
      expect(resultado.length).toBe(1);
      expect(resultado[0].cantidad).toBe(1);
    });
    it("debe aumentar la cantidad de un producto existente", () => {
      const carrito = [{ ...mouse, cantidad: 1 }];
      const resultado = agregarAlCarrito(carrito, mouse);
      expect(resultado[0].cantidad).toBe(2);
    });
    it("no debe superar el stock disponible al agregar", () => {
      const carrito = [{ ...mouse, cantidad: 5 }];
      const resultado = agregarAlCarrito(carrito, mouse);
      expect(resultado[0].cantidad).toBe(5);
    });
    it("debe aumentar la cantidad usando el bot\xF3n m\xE1s", () => {
      const carrito = [{ ...mouse, cantidad: 1 }];
      const resultado = modificarCantidad(carrito, 1, 1);
      expect(resultado[0].cantidad).toBe(2);
    });
    it("debe disminuir la cantidad usando el bot\xF3n menos", () => {
      const carrito = [{ ...mouse, cantidad: 3 }];
      const resultado = modificarCantidad(carrito, 1, -1);
      expect(resultado[0].cantidad).toBe(2);
    });
    it("debe quitar un producto cuando su cantidad llega a cero", () => {
      const carrito = [{ ...mouse, cantidad: 1 }];
      const resultado = modificarCantidad(carrito, 1, -1);
      expect(resultado.length).toBe(0);
    });
    it("no debe superar el stock al aumentar cantidad", () => {
      const carrito = [{ ...mouse, cantidad: 5 }];
      const resultado = modificarCantidad(carrito, 1, 1);
      expect(resultado[0].cantidad).toBe(5);
    });
    it("debe eliminar un producto seleccionado", () => {
      const carrito = [
        { ...mouse, cantidad: 1 },
        { ...teclado, cantidad: 1 }
      ];
      const resultado = quitarProducto(carrito, 1);
      expect(resultado.length).toBe(1);
      expect(resultado[0].id).toBe(2);
    });
    it("debe calcular la cantidad total de unidades", () => {
      const carrito = [
        { ...mouse, cantidad: 2 },
        { ...teclado, cantidad: 3 }
      ];
      expect(calcularCantidadTotal(carrito)).toBe(5);
    });
    it("debe calcular correctamente el precio total", () => {
      const carrito = [
        { ...mouse, cantidad: 2 },
        { ...teclado, cantidad: 1 }
      ];
      expect(calcularPrecioTotal(carrito)).toBe(79990);
    });
  });
})();
